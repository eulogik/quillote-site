# Quillote press facts

Quillote is a tiny Markdown and code editor with a real Live mode, built by Eulogik.

- Version: 0.1.0, public beta, 23 October 2026.
- Price: free beta. Pricing for 1.0 has not been decided.
- Platforms: macOS (universal), iPhone, Android. Windows and Linux installers are built by CI.
- macOS: 5.2 MB universal DMG, Apple Silicon and Intel, macOS 10.13+. Unsigned beta.
- Android: 7.2 MB signed arm64 APK. iOS: 3.4 MB App Store-signed IPA.
- Windows: 2.1 MB NSIS, 2.6 MB MSI. Linux: 2.9 MB .deb, 2.9 MB .rpm. Unsigned.
- Initial JavaScript: 141.1 KB gzipped. App CSS: 4.9 KB gzipped. Read chunk: 39.8 KB gzipped.
- Tests: 277 frontend, 26 Rust.
- One plain file, three views: Source, Live and Read.
- Live styles headings, emphasis, code and links in the buffer. Read renders tables, KaTeX math and images.
- No account, no analytics, no telemetry, no sync service.
- Built by Eulogik. Site: https://quillote.com
