# Quillote press facts

Quillote is a tiny Markdown and code editor with a real Live mode, built by Eulogik.

- Version: 0.1.3, public beta, 27 October 2026.
- Price: free. $0, with no paid tier, subscription or in-app purchase.
- Platforms: macOS (universal), iPhone, iPad, Android. Windows and Linux installers are built by CI.
- macOS: 5.2 MB universal DMG, Apple Silicon and Intel, macOS 10.13+. Unsigned beta.
- Android: 7.2 MB signed arm64 APK, Android 7.0 (API 24) or later. The Play AAB is built and signed but not uploaded yet.
- Windows: 2.1 MB NSIS, 2.6 MB MSI. Linux: 2.9 MB .deb, 2.9 MB .rpm. Unsigned, glibc 2.39 floor.
- iPhone and iPad: the 0.1.0 build is in App Store review. The 0.1.3 update is uploaded to App Store Connect. The 0.1.3 IPA is 3.4 MB.
- Initial JavaScript: 141.7 KB gzipped. App CSS: 5.0 KB gzipped. Read chunk: 39.8 KB gzipped.
- Tests: 288 frontend tests in 20 files, 26 Rust tests.
- One plain file, three views: Source, Live and Read.
- Live styles headings, emphasis, code and links in the buffer. Read renders tables, KaTeX math and images.
- No account, no analytics, no telemetry, no sync service.
- Phone files copy into the app sandbox. A new file saves in the same folder and reopens from Recents. Share-sheet export is the next mobile update.
- Built by Eulogik. Site: https://quillote.com

## Screenshots in this kit

The iPhone and iPad images are 0.1.3, Night theme, captured in Apple's iPhone and iPad simulators. The desktop image is 0.1.0.

- `Quillote-iphone-6.9-first-run.png`: iPhone 17 Pro Max, 1320 x 2868, first run.
- `Quillote-iphone-6.9-live.png`: iPhone 17 Pro Max, 1320 x 2868, Live mode.
- `Quillote-iphone-6.9-read.png`: iPhone 17 Pro Max, 1320 x 2868, Read mode.
- `Quillote-iphone-6.9-source.png`: iPhone 17 Pro Max, 1320 x 2868, Source mode.
- `Quillote-iphone-6.5-first-run.png`: iPhone 16 Plus, 1290 x 2796, first run.
- `Quillote-iphone-6.5-live.png`: iPhone 16 Plus, 1290 x 2796, Live mode.
- `Quillote-iphone-6.5-read.png`: iPhone 16 Plus, 1290 x 2796, Read mode.
- `Quillote-ipad-13-first-run.png`: iPad Pro 13-inch (M4), 2064 x 2752, first run.
- `Quillote-ipad-13-live.png`: iPad Pro 13-inch (M4), 2064 x 2752, Live mode.
- `Quillote-ipad-13-read.png`: iPad Pro 13-inch (M4), 2064 x 2752, Read mode.
- `Quillote-ipad-11-first-run.png`: iPad Pro 11-inch (M4), 1668 x 2420, first run.
- `Quillote-ipad-11-live.png`: iPad Pro 11-inch (M4), 1668 x 2420, Live mode.
- `Quillote-ipad-11-read.png`: iPad Pro 11-inch (M4), 1668 x 2420, Read mode.
- `Quillote-desktop-live.png`: macOS 0.1.0, Live mode, 2400 x 1600.
